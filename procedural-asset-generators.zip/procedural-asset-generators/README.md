# Trisball procedural asset generators

This bundle supplies the local source projects used by the Trisball level
editor to generate roots, jungle vines, and boulders. Generated GLBs are copied
into the game's `rope/public/generated-*` folders automatically.

## Requirements

- Windows
- Blender 5.2 installed at
  `C:\Program Files\Blender Foundation\Blender 5.2\blender.exe`, or set
  `BLENDER_PATH` to the Blender executable
- Python 3.11 or newer for the boulder generator
- Bun for the Trisball project

Install the boulder generator's Python packages:

```powershell
py -m pip install -r .\boulders\requirements.txt
```

## Connect the bundle to the editor

Extract this ZIP anywhere. Before starting the editor, set these environment
variables to the extracted directories:

```powershell
$env:ROOTS_PROJECT = "C:\path\to\procedural-asset-generators\roots"
$env:BOULDERS_V5_PROJECT = "C:\path\to\procedural-asset-generators\boulders\stylised_rocks_v5"
$env:BLENDER_PATH = "C:\Program Files\Blender Foundation\Blender 5.2\blender.exe"
```

Then, from the cloned repository:

```powershell
cd .\rope
bun install
bun run dev
```

Open the editor URL printed by Vite, normally
`http://localhost:3100/editor`. The editor's **Generate roots**, **Generate
boulder v5**, and **Generate vine v3** controls will use these projects.

The environment variables apply to the current PowerShell window. Set them
again in a new window, or add them to the user's Windows environment settings.

## What is included

- `roots`: root and vine v3 Blender generators, supporting Python modules, bark
  textures, and generator documentation
- `boulders/stylised_rocks_v5`: the boulder v5 generator and its source modules
- `boulders/requirements.txt`: Python dependencies used by the boulder generator

Preview renders, caches, logs, Blender snapshots, and generated models are
excluded. They are outputs rather than inputs to level generation.
